<div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
    <?php echo Form::label('name', 'Name', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('name', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

        <?php echo $errors->first('name', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
    <?php echo Form::label('email', 'Email', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::email('email', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

        <?php echo $errors->first('email', '<p class="help-block">:message</p>'); ?>

    </div>
</div><div class="form-group <?php echo e($errors->has('password') ? 'has-error' : ''); ?>">
    <?php echo Form::label('password', 'Password', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::password('password', ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

        <?php echo $errors->first('password', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<div class="form-group">
    <?php echo Form::label('project_id', 'Project', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php
            $aP = App\Project::where('status', 1)->doesntHave('client')->pluck('name', 'id');
            if(isset($user->project)) {
                $aP->put($user->project->id, $user->project->name);
            }
        ?>
        <?php echo Form::select('project_id', $aP, isset($user) && isset($user->project) ? $user->project->id : null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

    </div>
</div>

<div class="form-group">
    <?php echo Form::label('permissions', 'User access', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::select('permissions[]', ['view-digital-report' => 'view-digital-report', 'view-smm-report' => 'view-smm-report'], isset($user)?$user->permissions->pluck('name','name'):null , ('' == 'required') ? ['class' => 'form-control', 'required' => 'required', 'multiple'=>'multiple'] : ['class' => 'form-control', 'multiple']); ?>

        <?php echo $errors->first('permissions', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<div class="form-group">
    <div class="col-md-offset-4 col-md-4">
        <?php echo Form::submit(isset($submitButtonText) ? $submitButtonText : 'Create', ['class' => 'btn btn-primary']); ?>

    </div>
</div>
