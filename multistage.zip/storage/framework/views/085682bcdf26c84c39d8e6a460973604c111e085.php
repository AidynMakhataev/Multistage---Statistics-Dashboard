<div class="form-group <?php echo e($errors->has('project_id') ? 'has-error' : ''); ?>">
    <?php echo Form::label('project_id', 'Project', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::select('project_id', App\Project::pluck('name', 'id'), old('project_id'), ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

        <?php echo $errors->first('user_id', '<p class="help-block">:message</p>'); ?>

    </div>
</div>

<div class="form-group <?php echo e($errors->has('start') ? 'has-error' : ''); ?>">
    <?php echo Form::label('start', 'Start', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::date('start', isset($digitalreport) ? $digitalreport->start : null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

        <small class="form-text text-muted">Campaign start date(required)</small>
        <?php echo $errors->first('start', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<div class="form-group <?php echo e($errors->has('end') ? 'has-error' : ''); ?>">
    <?php echo Form::label('end', 'End', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::date('end', isset($digitalreport) ? $digitalreport->end : null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

        <small class="form-text text-muted">Campaign end date(required)</small>
        <?php echo $errors->first('end', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<div class="form-group <?php echo e($errors->has('video_link') ? 'has-error' : ''); ?>">
    <?php echo Form::label('video_link', 'Link to youtube video', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('video_link', null, ('' == 'required') ? ['class' => 'form-control', 'required' => 'required'] : ['class' => 'form-control']); ?>

        <?php echo $errors->first('video_link', '<p class="help-block">:message</p>'); ?>

    </div>
</div>


