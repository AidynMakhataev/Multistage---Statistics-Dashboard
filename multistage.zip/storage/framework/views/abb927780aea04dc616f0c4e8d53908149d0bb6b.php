

<div class="form-group <?php echo e($errors->has('project_id') ? 'has-error' : ''); ?>">
    <?php echo Form::label('project_id', 'Project', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::select('project_id', App\Project::pluck('name', 'id'), old('project_id'), ['class' => 'form-control', 'required' => 'required']); ?>

        <?php echo $errors->first('user_id', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<div class="form-group <?php echo e($errors->has('type') ? 'has-error' : ''); ?>">
    <?php echo Form::label('type', 'Social Type', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::select('type',['facebook' => 'facebook','instagram' => 'instagram','youtube' => 'youtube','vk' => 'vk'] , old('type'), ['class' => 'form-control', 'required' => 'required']); ?>

        <?php echo $errors->first('type', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<div class="form-group <?php echo e($errors->has('views') ? 'has-error' : ''); ?>">
    <?php echo Form::label('views', 'Number of views', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('views', null, ['class' => 'form-control', 'required' => 'required']); ?>

        <?php echo $errors->first('views', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<div class="form-group <?php echo e($errors->has('reposts') ? 'has-error' : ''); ?>">
    <?php echo Form::label('reposts', 'Number of reposts', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::number('reposts', null, ['class' => 'form-control', 'required' => 'required']); ?>

        <?php echo $errors->first('reposts', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<div class="form-group <?php echo e($errors->has('likes') ? 'has-error' : ''); ?>">
    <?php echo Form::label('likes', 'Number of likes', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::number('likes', null, ['class' => 'form-control', 'required' => 'required']); ?>

        <?php echo $errors->first('likes', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<div class="form-group <?php echo e($errors->has('link') ? 'has-error' : ''); ?>">
    <?php echo Form::label('link', 'Link to source', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('link', null, ['class' => 'form-control', 'required' => 'required']); ?>

        <?php echo $errors->first('link', '<p class="help-block">:message</p>'); ?>

    </div>
</div>

<comments :data="<?php echo e(isset($comment->comments) ? json_encode($comment->comments) : json_encode([])); ?>"></comments>    

<div class="form-group">
    <div class="col-md-offset-4 col-md-4">
        <?php echo Form::submit(isset($submitButtonText) ? $submitButtonText : 'Create', ['class' => 'btn btn-primary']); ?>

    </div>
</div>
