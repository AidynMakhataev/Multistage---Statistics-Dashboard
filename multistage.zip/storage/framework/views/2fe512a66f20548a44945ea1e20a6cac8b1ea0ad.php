<section class="ms-social">
    <div class="container">
        <div class="row">
           <div class="col-md-3">
                <div class="ms-social__inner">
                    <div class="ms-social__titleWrp">
                        <a href="<?php if(isset($project->facebook->link)): ?> <?php echo e($project->facebook->link); ?> <?php endif; ?>" class="ms-social__title">Facebook</a>
                    </div> 
                    <div class="ms-social__commentWrp">
                        <?php if(isset($project->facebook->likes)): ?>
                        <div class="ms-social__likesWrp">
                            <div class="ms-social__likesInner">
                                <div class="ms-social__likes"></div>
                                <div class="ms-social__likes ms-social__likes--smile"></div>
                                <div class="ms-social__likes ms-social__likes--heart"></div>
                                <span class="ms-social__likesNum"><?php echo e($project->facebook->likes); ?></span>
                            </div>
                        </div>
                        <?php endif; ?>
                        <?php if(isset($project->facebook->reposts)): ?>
                        <div class="ms-social__sharedWrp">
                            <span class="ms-social__shared">Этим поделились: <?php echo e($project->facebook->reposts); ?></span>
                        </div>
                        <?php endif; ?>
                        <ul class="ms-social__list">
                        <?php if(isset($project->facebook->comments)): ?>
                          <?php $__currentLoopData = $project->facebook->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="ms-social__item"><b><?php echo e($comment['author']); ?></b> <?php echo e($comment['comment']); ?></li>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <li class="ms-social__item" style="opacity: 0.5;">НЕТ КОММЕНТАРИЕВ</li>    
                        <?php endif; ?>  
                        </ul>
                    </div>
                    <?php if(isset($project->facebook->views)): ?>
                    <div class="ms-social__watchWrp">
                        <span class="ms-social__watch">Просмотры: <?php echo e($project->facebook->views); ?></span>
                    </div>
                    <?php endif; ?>
                </div>        
           </div> 
    
            <div class="col-md-3">
                <div class="ms-social__inner">
                    <div class="ms-social__titleWrp">
                        <a href="<?php if(isset($project->instagram->link)): ?> <?php echo e($project->instagram->link); ?> <?php endif; ?>" class="ms-social__title">Instagram</a>
                    </div>
                    <div class="ms-social__commentWrp">
                        <ul class="ms-social__list">
                        <?php if(isset($project->instagram->comments)): ?>
                          <?php $__currentLoopData = $project->instagram->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="ms-social__item"><b><?php echo e($comment['author']); ?></b> <?php echo e($comment['comment']); ?></li>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <li class="ms-social__item" style="opacity: 0.5;">НЕТ КОММЕНТАРИЕВ</li>    
                        <?php endif; ?>  
                        </ul>
                    </div>
                    <?php if(isset($project->instagram->views)): ?>
                    <div class="ms-social__watchWrp">
                        <span class="ms-social__watch">Просмотры: <?php echo e($project->instagram->views); ?></span>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="col-md-3">
                <div class="ms-social__inner">
                    <div class="ms-social__titleWrp">
                        <a href="<?php if(isset($project->youtube->link)): ?> <?php echo e($project->youtube->link); ?> <?php endif; ?>" class="ms-social__title">YouTube</a>
                    </div>
                    <div class="ms-social__commentWrp">
                        <ul class="ms-social__list">
                        <?php if(isset($project->youtube->comments)): ?>
                          <?php $__currentLoopData = $project->youtube->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="ms-social__item"><b><?php echo e($comment['author']); ?></b> <?php echo e($comment['comment']); ?></li>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <li class="ms-social__item" style="opacity: 0.5;">НЕТ КОММЕНТАРИЕВ</li>    
                        <?php endif; ?>  
                        </ul>
                    </div>
                    <?php if(isset($project->youtube->views)): ?>
                    <div class="ms-social__watchWrp">
                        <span class="ms-social__watch">Просмотры: <?php echo e($project->youtube->views); ?></span>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-md-3">
                <div class="ms-social__inner">
                    <div class="ms-social__titleWrp">
                    <a href="<?php if(isset($project->vk->link)): ?> <?php echo e($project->vk->link); ?> <?php endif; ?>" class="ms-social__title">Vk</a>
                    </div>
                    <div class="ms-social__commentWrp" style="text-align: center;">
                        <ul class="ms-social__list">
                        <?php if(isset($project->vk->comments)): ?>
                          <?php $__currentLoopData = $project->vk->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="ms-social__item"><b><?php echo e($comment['author']); ?></b> <?php echo e($comment['comment']); ?></li>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <li class="ms-social__item" style="opacity: 0.5;">НЕТ КОММЕНТАРИЕВ</li>    
                        <?php endif; ?>  
                        </ul>
                    </div>
                    <?php if(isset($project->vk->views)): ?>
                    <div class="ms-social__watchWrp">
                        <span class="ms-social__watch">Просмотры: <?php echo e($project->vk->views); ?></span>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>