<section class="ms-video">
    <div class="row justify-content-center">
        <div class="col-xl-7">
            <div class="ms-video__wrp">
                <iframe width="100%" height="100%" src="<?php echo e($report->video_link); ?>" frameborder="0" gesture="media" allow="encrypted-media" allowfullscreen></iframe>
            </div>
        </div>
    </div>
</section>
