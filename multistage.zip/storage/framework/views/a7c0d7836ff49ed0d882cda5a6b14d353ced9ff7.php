<div class="ms-header">
    <div class="container">
        <div class="row">
            <div class="col-xl-12 d-flex justify-content-between">
                <div class="ms-header__nameWrp">
                    <div class="ms-header__logoWrp">
                        <img src="<?php echo e(asset('build/images/ms-header-logo.png')); ?>" onclick="window.document.location.href='/'" alt="" class="ms-header__logo">
                    </div>
                    <a href="<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-digital-report')): ?> <?php echo e(route('digital')); ?> <?php else: ?> # <?php endif; ?>" class="ms-header__name ms-header__name--digital <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-digital-report')): ?> ms-header__name--active <?php endif; ?>">Digital Campaign<br> Report</a>
                    <a href="<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-smm-report')): ?> <?php echo e(route('smm')); ?> <?php else: ?> # <?php endif; ?>" class="ms-header__name ms-header__name--smm align-top <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-smm-report')): ?> ms-header__name--active <?php endif; ?>">SMM Report</a>
                    <span class="ms-header__name ms-header__name--active align-top"><?php echo e($project->name); ?></span>
                </div>
                <div class="ms-header__dateWrp">
                    <div class="ms-header__labelWrp ms-header__name ms-header__name--active">Current period between:</div>
                        <select name="period" id="" class="ms-header__date" onChange="window.document.location.href=this.options[this.selectedIndex].value;">
                            <option value="default"><?php echo e($report->start->toFormattedDateString()); ?> - <?php echo e($report->end->toFormattedDateString()); ?></option>
                            <?php if(count($reportPeriods) > 0): ?>
                                <?php $__currentLoopData = $reportPeriods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $period): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e(env('APP_URL').'digital/period/'.$period->id); ?>"><?php echo e($period->start->toFormattedDateString()); ?> - <?php echo e($period->end->toFormattedDateString()); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                </div>
                <div class="ms-header__avatarWrp">
                    <img src="<?php echo e(asset('build/images/ms-header-avatar.png')); ?>" alt="" class="ms-header__avatar">
                    <div class="ms-header__logoutWrp">
                        <span class="ms-header__logout">
                            <a  href="<?php echo e(route('logout')); ?>"
                                onclick="event.preventDefault();
                                document.getElementById('logout-form').submit();">
                                    Logout
                            </a>
                        </span>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo e(csrf_field()); ?>

                        </form>
                    </div>


                </div>
            </div>
        </div>
    </div>
</div>
