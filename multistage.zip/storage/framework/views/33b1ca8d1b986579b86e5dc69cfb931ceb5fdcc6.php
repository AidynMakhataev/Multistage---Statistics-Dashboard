<?php $__env->startSection('content'); ?>
<div class="ms-auth">
    <div class="ms-auth__inner">
        <div class="ms-auth__titleWrp">
            <span class="ms-auth__title">Авторизация</span>
        </div>
        <form action="<?php echo e(route('login')); ?>" method="POST" class="ms-auth__form">
            <?php echo e(csrf_field()); ?>

            <div class="ms-auth__group">
                <label class="ms-auth__label" for="email">Email</label>
                <input type="email" id="email" name="email" class="ms-auth__input" required>

                <?php if($errors->has('email')): ?>
                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
            <div class="ms-auth__group">
                <label class="ms-auth__label" for="password">Пароль</label>
                <input type="password" id="password" name="password" class="ms-auth__input" required>

                <?php if($errors->has('password')): ?>
                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
            <button class="ms-auth__button">Войти</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>