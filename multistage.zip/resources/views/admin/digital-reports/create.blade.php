@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">Create New DigitalReport</div>
                    <div class="panel-body">
                        <a href="{{ url('/admin/digital-reports') }}" title="Back"><button class="btn btn-warning btn-xs"><i class="fa fa-arrow-left" aria-hidden="true"></i> Back</button></a>
                        <br />
                        <br />

                        @if ($errors->any())
                            <ul class="alert alert-danger">
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        @endif

                        {!! Form::open(['url' => '/admin/digital-reports', 'class' => 'form-horizontal', 'files' => true]) !!}

                        @include ('admin.digital-reports.form')

                        <actions-overview :parameters="{{ json_encode([])  }}"></actions-overview>
                        <people-overview :parameters="{{ json_encode(['gender' => ['male' => 0, 'female' => 0], 'ages' => []])  }}"></people-overview>
                        <country-report :parameters="{{ json_encode([]) }}"></country-report>

                        <div class="form-group">
                            <div class="col-md-offset-4 col-md-4">
                                {!! Form::submit(isset($submitButtonText) ? $submitButtonText : 'Create', ['class' => 'btn btn-primary']) !!}
                            </div>
                        </div>

                        {!! Form::close() !!}

                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
