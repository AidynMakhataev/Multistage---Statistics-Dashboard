<template>
  <vue-instagram token="2463580803.ebe32e5.cec2b5a6feca44be818b24c623eb3c01" username="moreman122" :count="5" :tags="['apple']">
    <template slot="feeds" slot-scope="props">
      <li class="fancy-list"> {{ props.feed.link }} </li>
    </template>
    <template slot="error" slot-scope="props">
      <div class="fancy-alert"> {{ props.error.error_message }} </div>
    </template>
  </vue-instagram>
</template>

<script>
import Vue from 'vue'
import VueInstagram from 'vue-instagram'
Vue.use(VueInstagram)
export default {
  name: 'App',

  components: {
    VueInstagram
  }
}
</script>