function modalCall(mod, btn){
    var modal = $(mod);
    var modWrp = modal.find('.bs-rqmodal__wrp');
    var btn = $(btn);

    btn.on("click", function(){
        $('.bs-rqmodal').hide();
        modal.show();
        if ($(window).width() > 992){
            var hgt = modal.find(".bs-rqmodal__inner").outerHeight();
            modal.find('.bs-rqmodal__content').outerHeight(hgt);
        }
    });
    modWrp.on("click", function(){
        modal.hide();
    });
    $('.js-bs-rqmodal__close').click(function () {
        modal.hide();
    });
}
modalCall('.js-projectName-call__modal', ".js-projcetName-call__btn");
