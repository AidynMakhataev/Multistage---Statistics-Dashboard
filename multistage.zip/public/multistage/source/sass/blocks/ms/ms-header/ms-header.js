$(document).ready(function () {
	var logoutWrp = $('.ms-header__logoutWrp'),
		avatarWrp = $('.ms-header__avatarWrp'),
		// digital = $('.ms-header__name--digital'),
		digitalSection = $('.ms-digital');
		// smm = $('.ms-header__name--smm'),
		// smmSection = $('.ms-smm');

	avatarWrp.hover(function () {
		TweenMax.to(logoutWrp, 0.3, {css:{"opacity":"1"}});
	},function () {
		TweenMax.to(logoutWrp, 0.3, {css:{"opacity":"0"}});
	});
	// digital.on('click',function () {
	// 	TweenMax.to(digitalSection, 0.1, {css:{"display":"block"}});
	// 	TweenMax.to(smmSection, 0.1, {css:{"display":"none"}});
	// 	// $(this).addClass('ms-header__name--active');
	// 	// smm.removeClass('ms-header__name--active');
	// });
	// smm.on('click',function () {
	// 	TweenMax.to(digitalSection, 0.1, {css:{"display":"none"}});
	// 	TweenMax.to(smmSection, 0.1, {css:{"display":"block"}});
	// 	$(this).addClass('ms-header__name--active');
	// 	digital.removeClass('ms-header__name--active');
	// });
})