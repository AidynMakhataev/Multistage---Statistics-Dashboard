var ctx = document.getElementById("myPeopleChart").getContext('2d');
var myPieChart = new Chart(ctx,{
    type: 'pie',
    data: {
        datasets: [{
            data: [44, 56],
            backgroundColor: [
                '#ff6384',
                '#36a2eb'
            ]
        }],
        // These labels appear in the legend and in the tooltips when hovering different arcs
        labels: [
            'Male',
            'Female'
        ]
    },
    options: {
        legend: {
            display: false
        }
    }
});

//horizontal
var ctx = document.getElementById("peopleHorizBar").getContext('2d');
var myBarChart = new Chart(ctx, {
    type: 'horizontalBar',
    data: {
        labels: ["55+","45-54","35-44","25-34","18-24"],
        datasets: [{
            data: [0,0,0,49,51],
            backgroundColor: [
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 99, 132, 0.2)'
            ],
            borderColor: [
                'rgba(54, 162, 235, 1)',
                'rgba(255,99,132,1)'
            ],
            borderWidth: 1
        }]
    },

    options: {
        legend: {
            display: false
        }
    }
});

//SMM
// var ctx = document.getElementById("myPeopleChartSMM").getContext('2d');
// var myPieChart = new Chart(ctx,{
//     type: 'pie',
//     data: {
//         datasets: [{
//             data: [35, 65],
//             backgroundColor: [
//                 '#ff6384',
//                 '#36a2eb'
//             ]
//         }],
//         // These labels appear in the legend and in the tooltips when hovering different arcs
//         labels: [
//             'Male',
//             'Female'
//         ]
//     },
//     options: {
//         legend: {
//             display: false
//         }
//     }
// });

// //horizontal
// var ctx = document.getElementById("peopleHorizBarSMM").getContext('2d');
// var myBarChart = new Chart(ctx, {
//     type: 'horizontalBar',
//     data: {
//         labels: ["55+","45-54","35-44","25-34","18-24"],
//         datasets: [{
//             data: [5,10,25,25,35],
//             backgroundColor: [
//                 'rgba(54, 162, 235, 0.2)',
//                 'rgba(255, 99, 132, 0.2)',
//                 'rgba(54, 162, 235, 0.2)',
//                 'rgba(54, 162, 235, 0.2)',
//                 'rgba(255, 99, 132, 0.2)'
//             ],
//             borderColor: [
//                 'rgba(54, 162, 235, 1)',
//                 'rgba(255,99,132,1)'
//             ]
//         }]
//     },

//     options: {
//         legend: {
//             display: false
//         }
//     }
// });
