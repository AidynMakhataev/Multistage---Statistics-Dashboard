var ctx = document.getElementById("myCountryChart").getContext('2d');
var myPieChart = new Chart(ctx, {
    type: 'pie',
    data: {
        datasets: [{
            data: [24, 21, 14, 13, 7, 7, 14],
            backgroundColor: [
                '#36a2eb',
                '#F17F42',
                '#58C9B9',
                '#30A9DE',
                '#EFFFE9',
                '#C16200',
                '#D81159',
            ]
        }],
        // These labels appear in the legend and in the tooltips when hovering different arcs
        labels: [
            'Almaty',
            'Astana',
            'Shymkent',
            'Karaganda',
            'Aktau',
            'Atyrau',
            'Others'
        ]
    },
    options: {
        legend: {
            display: true,
            position: 'right'
        }
    }
});

//SMM
// var ctx = document.getElementById("myCountryChartSMM").getContext('2d');
// var myPieChart = new Chart(ctx, {
//     type: 'pie',
//     data: {
//         datasets: [{
//             data: [76, 7, 7, 6, 1, 1, 2],
//             backgroundColor: [
//                 '#36a2eb',
//                 '#F17F42',
//                 '#58C9B9',
//                 '#30A9DE',
//                 '#EFFFE9',
//                 '#C16200',
//                 '#D81159',
//             ]
//         }],
//         // These labels appear in the legend and in the tooltips when hovering different arcs
//         labels: [
//             'Kazakhstan',
//             'India',
//             'Mexico',
//             'Russia',
//             'Turkey',
//             'Uzbekistan',
//             'Others'
//         ]
//     },
//     options: {
//         legend: {
//             display: true,
//             position: 'right'
//         }
//     }
// });