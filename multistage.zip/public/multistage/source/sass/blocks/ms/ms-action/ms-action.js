$(document).ready(function () {
	var action = $('#action'),
		people = $('#people'),
		view = $('#view'),
		firstTab = $('.ms-action--first'),
		secondTab = $('.ms-action--secondTab'),
		thirdTab = $('.ms-action--thirdTab'),
		msAction = $('.ms-action'),
		tab1 = $('.ms-heading__heading--action'),
		tab2 = $('.ms-heading__heading--people');
		tab3 = $('.ms-heading__heading--view'),
        title = $('.ms-action__title');

	action.on('click', function () {
		firstTab.removeClass('ms-action--second');
		secondTab.addClass('ms-action--second');
		thirdTab.addClass('ms-action--second');
		tab1.addClass('ms-heading__heading--active');
		tab2.removeClass('ms-heading__heading--active');
		tab3.removeClass('ms-heading__heading--active');
        title.text("Action overview");
	});
	people.on('click', function () {
		secondTab.removeClass('ms-action--second');
		firstTab.addClass('ms-action--second');
		thirdTab.addClass('ms-action--second');
		tab2.addClass('ms-heading__heading--active');
		tab1.removeClass('ms-heading__heading--active');
		tab3.removeClass('ms-heading__heading--active');
        title.text("People Reached Plan vs Fact");
	});
	view.on('click', function () {
		thirdTab.removeClass('ms-action--second');
		firstTab.addClass('ms-action--second');
		secondTab.addClass('ms-action--second');
		tab3.addClass('ms-heading__heading--active');
		tab1.removeClass('ms-heading__heading--active');
		tab2.removeClass('ms-heading__heading--active');
        title.text("Views Plan vs Fact");
	});
})

var ctx = document.getElementById("actionBar").getContext('2d');
var actionBar = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: ["Display", "Pre-Roll", "Facebook", "Instagram", "YouTube","Vk"],
        datasets: [{
            data: [500000,80000,40000,90000,60000,90000],
            backgroundColor: [
                'rgba(54, 162, 235, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(54, 162, 235, 0.2)'
            ],
            borderColor: [
                'rgba(54, 162, 235, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(54, 162, 235, 1)'
            ]
        },{
        	data: [75930,25670,104783,245987,130000,27415],
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(255, 99, 132, 0.2)',
                'rgba(255, 99, 132, 0.2)',
                'rgba(255, 99, 132, 0.2)',
                'rgba(255, 99, 132, 0.2)',
                'rgba(255, 99, 132, 0.2)'
            ],
            borderColor: [
                'rgba(255,99,132,1)',
                'rgba(255,99,132,1)',
                'rgba(255,99,132,1)',
                'rgba(255,99,132,1)',
                'rgba(255,99,132,1)',
                'rgba(255,99,132,1)'
            ]
        }]
    },
    options: {
        legend: {
            display: false
        },
        scales: {
            yAxes: [{
                ticks: {
		        	min: 0
		        }
            }]
        }
    }
});
var ctx = document.getElementById("viewBar").getContext('2d');
var viewBar = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: ["Display", "Pre-Roll", "Facebook", "Instagram", "YouTube","Vk"],
        datasets: [{
            data: [500000,80000,40000,90000,60000,90000],
            backgroundColor: [
                'rgba(54, 162, 235, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(54, 162, 235, 0.2)'
            ],
            borderColor: [
                'rgba(54, 162, 235, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(54, 162, 235, 1)'
            ]
        },{
            data: [19845,16340,40955,118598,37700,11032],
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(255, 99, 132, 0.2)',
                'rgba(255, 99, 132, 0.2)',
                'rgba(255, 99, 132, 0.2)',
                'rgba(255, 99, 132, 0.2)',
                'rgba(255, 99, 132, 0.2)'
            ],
            borderColor: [
                'rgba(255,99,132,1)',
                'rgba(255,99,132,1)',
                'rgba(255,99,132,1)',
                'rgba(255,99,132,1)',
                'rgba(255,99,132,1)',
                'rgba(255,99,132,1)'
            ]
        }]
    },
    options: {
        legend: {
            display: false
        },
        scales: {
            yAxes: [{
                ticks: {
                    min: 0
                }
            }]
        }
    }
});

//SMM
// var ctx = document.getElementById("actionBarSMM").getContext('2d');
// var actionBar = new Chart(ctx, {
//     type: 'bar',
//     data: {
//         labels: ["Display", "Pre-Roll", "Facebook", "Instagram", "YouTube","Vk"],
//         datasets: [{
//             data: [500000,80000,40000,90000,60000,90000],
//             backgroundColor: [
//                 'rgba(54, 162, 235, 0.2)',
//                 'rgba(54, 162, 235, 0.2)',
//                 'rgba(54, 162, 235, 0.2)',
//                 'rgba(54, 162, 235, 0.2)',
//                 'rgba(54, 162, 235, 0.2)',
//                 'rgba(54, 162, 235, 0.2)'
//             ],
//             borderColor: [
//                 'rgba(54, 162, 235, 1)',
//                 'rgba(54, 162, 235, 1)',
//                 'rgba(54, 162, 235, 1)',
//                 'rgba(54, 162, 235, 1)',
//                 'rgba(54, 162, 235, 1)',
//                 'rgba(54, 162, 235, 1)'
//             ]
//         },{
//             data: [37041,14825,104783,164207,27890,20415],
//             backgroundColor: [
//                 'rgba(255, 99, 132, 0.2)',
//                 'rgba(255, 99, 132, 0.2)',
//                 'rgba(255, 99, 132, 0.2)',
//                 'rgba(255, 99, 132, 0.2)',
//                 'rgba(255, 99, 132, 0.2)',
//                 'rgba(255, 99, 132, 0.2)'
//             ],
//             borderColor: [
//                 'rgba(255,99,132,1)',
//                 'rgba(255,99,132,1)',
//                 'rgba(255,99,132,1)',
//                 'rgba(255,99,132,1)',
//                 'rgba(255,99,132,1)',
//                 'rgba(255,99,132,1)'
//             ]
//         }]
//     },
//     options: {
//         legend: {
//             display: false
//         },
//         scales: {
//             yAxes: [{
//                 ticks: {
//                     min: 0
//                 }
//             }]
//         }
//     }
// });
// var ctx = document.getElementById("viewBarSMM").getContext('2d');
// var viewBar = new Chart(ctx, {
//     type: 'bar',
//     data: {
//         labels: ["Display", "Pre-Roll", "Facebook", "Instagram", "YouTube","Vk"],
//         datasets: [{
//             data: [500000,80000,40000,90000,60000,90000],
//             backgroundColor: [
//                 'rgba(54, 162, 235, 0.2)',
//                 'rgba(54, 162, 235, 0.2)',
//                 'rgba(54, 162, 235, 0.2)',
//                 'rgba(54, 162, 235, 0.2)',
//                 'rgba(54, 162, 235, 0.2)',
//                 'rgba(54, 162, 235, 0.2)'
//             ],
//             borderColor: [
//                 'rgba(54, 162, 235, 1)',
//                 'rgba(54, 162, 235, 1)',
//                 'rgba(54, 162, 235, 1)',
//                 'rgba(54, 162, 235, 1)',
//                 'rgba(54, 162, 235, 1)',
//                 'rgba(54, 162, 235, 1)'
//             ]
//         },{
//             data: [10340,9976,35642,65743,10562,8570],
//             backgroundColor: [
//                 'rgba(255, 99, 132, 0.2)',
//                 'rgba(255, 99, 132, 0.2)',
//                 'rgba(255, 99, 132, 0.2)',
//                 'rgba(255, 99, 132, 0.2)',
//                 'rgba(255, 99, 132, 0.2)',
//                 'rgba(255, 99, 132, 0.2)'
//             ],
//             borderColor: [
//                 'rgba(255,99,132,1)',
//                 'rgba(255,99,132,1)',
//                 'rgba(255,99,132,1)',
//                 'rgba(255,99,132,1)',
//                 'rgba(255,99,132,1)',
//                 'rgba(255,99,132,1)'
//             ]
//         }]
//     },
//     options: {
//         legend: {
//             display: false
//         },
//         scales: {
//             yAxes: [{
//                 ticks: {
//                     min: 0
//                 }
//             }]
//         }
//     }
// });