'use strict';

// Include gulp
var gulp = require('gulp'),
    plugins = require('gulp-load-plugins')(),
    params = require('yargs').argv,
    pngquant = require('imagemin-pngquant'),
    rename    = require('gulp-rename'),
    VueModule = require('gulp-vue-module'),
    sources = {
        scripts: [
            'node_modules/jquery/dist/jquery.js',
            'source/javascript/*.js',
            'source/sass/blocks/**/*.js',
        ],
        sass: ['source/sass/main.scss'],
        images: ['source/img/**/*.+(png|jpg|JPG|PNG|svg)'],
        fonts: ['source/fonts/**/*'],
        html: ['*.html']
    },
    production = params.prod ? false : true,
    browserSync = require("browser-sync"),
    reload = browserSync.reload;

function handleError(err) {
    console.log(err.toString());
    this.emit('end');
}

var config = {
    server: {
        baseDir: "./"
    },
    tunnel: false,
    host: 'localhost',
    port: 8000,
    logPrefix: "at",
    // Open the site in Chrome
    browser: "default"
};

gulp.task('vue', function() {
    return gulp.src('source/vue/*.vue')
        .pipe(VueModule({
            debug : true
        }))
        .pipe(rename({extname : ".js"}))
        .pipe(gulp.dest("build/js"));
});

gulp.task('webserver', function () {
    browserSync(config);
});

gulp.task('scripts', function () {
    return gulp.src(sources.scripts)
        .pipe(plugins.sourcemaps.init())
        .pipe(plugins.concat('main.js'))
        .pipe(plugins.if(
            !production, plugins.uglify()
                .on('error', handleError))
        )
        .pipe(plugins.sourcemaps.write('./'))
        .pipe(gulp.dest('build/js'))
        .pipe(reload({stream: true}));
});

gulp.task('fonts', function () {
    return gulp.src(sources.fonts)
        .pipe(gulp.dest('build/fonts'));
});

gulp.task('sass', function () {
    var sassOpts = { outputStyle: 'compressed' };

    if (production) {
        sassOpts = { outputStyle: 'expanded' }
    }

    return gulp
        .src(sources.sass)
        .pipe(plugins.sourcemaps.init())
        .pipe(plugins.sassGlob())
        .pipe(plugins.sass(sassOpts).on('error', plugins.sass.logError))
        .pipe(plugins.autoprefixer())
        .pipe(plugins.sourcemaps.write('./'))
        .pipe(gulp.dest('build/css'))
        .pipe(reload({stream: true}));
});

gulp.task('images', function () {
    return gulp.src(sources.images)
        .pipe(plugins.cache(plugins.imagemin({
            optimizationLevel: 5,
            progressive: true,
            interlaced: true ,
            use: [pngquant()]
        })))
        .pipe(gulp.dest('build/images'))
        .pipe(reload({stream: true}));
});

// watching for changes
gulp.task('watch', function () {

    plugins.watch(sources.html, function () {
        gulp.src(sources.html)
            .pipe(reload({stream: true}));
    });

    plugins.watch(sources.scripts, function () {
        gulp.start('scripts');
    });

    plugins.watch(sources.images, function () {
        gulp.start('images');
    });

    plugins.watch('source/sass/**/*.scss', function () {
        gulp.start('sass');
    });

    plugins.watch('source/fonts/**/*', function () {
        gulp.start('fonts');
    });

    plugins.watch('source/vue/*.vue', function () {
        gulp.start('vue');
    });
});

gulp.task('build', [
    'scripts',
    'sass',
    'images',
    'fonts',
    'vue'
]);

// Default task
gulp.task('default', ['build', 'webserver', 'watch', 'vue']);
