<?php

if (isset($_POST['name']) && isset($_POST['password'])) {
	if ($_POST['name'] == 'galazolin' && $_POST['password'] == '123123gel') {
		header("Location:home.html");
	}
	else {
		header("Location:index.html");
	}
}